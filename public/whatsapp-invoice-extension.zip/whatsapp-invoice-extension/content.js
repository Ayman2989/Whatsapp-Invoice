// content.js (you can keep it empty for now)

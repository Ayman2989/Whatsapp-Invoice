document.getElementById("extractBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const isValidPhone = (text) => {
        const cleaned = text.replace(/\s/g, ""); // remove spaces
        return /^\+974\d{6,}$/.test(cleaned);
      };

      const extractPrimaryPhone = () => {
        try {
          const mainDiv = document.getElementById("main");
          if (!mainDiv) {
            console.log("Primary: #main not found");
            return null;
          }

          const level1Div = mainDiv.querySelector("div");
          if (!level1Div) {
            console.log("Primary: level1Div not found");
            return null;
          }
          const header = mainDiv.querySelector("header");
          if (!header) {
            console.log("Primary: header not found");
            return null;
          }

          const level2Div_1 = header.querySelector("div");
          if (!level2Div_1) {
            console.log("Primary: level2Div_1 inside header not found");
            return null;
          }

          const level2Div_2 = level2Div_1.nextElementSibling;
          if (!level2Div_2)
            if (!level2Div_2) {
              console.log("Primary: second level2Div inside header not found");
              return null;
            }
          const level3Div = level2Div_2.querySelector("div");
          if (!level3Div) {
            console.log("Primary: level3Div not found");
            return null;
          }

          const level4Div = level3Div.querySelector("div");
          if (!level4Div) {
            console.log("Primary: level4Div not found");
            return null;
          }

          const level5Div = level4Div.querySelector("div");
          if (!level5Div) {
            console.log("Primary: level5Div not found");
            return null;
          }

          const level6Div = level5Div.querySelector("div");
          if (!level6Div) {
            console.log("Primary: level6Div not found");
            return null;
          }

          const span = level6Div.querySelector("span");
          if (!span) {
            console.log("Primary: span not found");
            return null;
          }

          console.log("Primary: found phone:", span.innerText.trim());
          return span.innerText.trim();
        } catch (err) {
          console.log("Primary extraction error:", err);
          return null;
        }
      };

      const extractBackupNameAndNumber = () => {
        try {
          const mainDiv = document.getElementById("main");
          if (!mainDiv) {
            console.log("Backup: #main not found");
            return null;
          }
          console.log("Backup: found #main");

          // Go OUT one layer from #main
          const outerLayer = mainDiv.parentElement;
          if (!outerLayer) {
            console.log("Backup: outerLayer (parent of #main) not found");
            return null;
          }
          console.log("Backup: found outerLayer");

          // Go to sibling div of outerLayer
          const siblingOfOuterLayer = outerLayer.nextElementSibling;
          if (!siblingOfOuterLayer) {
            console.log("Backup: siblingOfOuterLayer not found");
            return null;
          }
          console.log("Backup: found siblingOfOuterLayer");
          // Drill down inside siblingOfOuterLayer
          const level1Span = siblingOfOuterLayer.querySelector("span");
          if (!level1Span) {
            console.log("Backup: level1Span not found");
            return null;
          }
          console.log("Backup: found level1Span");
          const level2Div = level1Span.querySelector("div");
          if (!level2Div) {
            console.log("Backup: level2Div not found");
            return null;
          }
          console.log("Backup: found level2Div");

          const level3Span = level2Div.querySelector("span");
          if (!level3Span) {
            console.log("Backup: level3Span not found");
            return null;
          }
          console.log("Backup: found level3Span");

          const level4Div = level3Span.querySelector("div");
          if (!level4Div) {
            console.log("Backup: level4Div not found");
            return null;
          }
          console.log("Backup: found level4Div");

          const level5Header = level4Div.querySelector("header");
          if (!level5Header) {
            console.log("Backup: level5Header not found");
            return null;
          }
          console.log("Backup: found level5Header");

          // Get sibling div of level5Header (not inside it)
          const level5SiblingDiv = level5Header.nextElementSibling;
          if (!level5SiblingDiv) {
            console.log(
              "Backup: level5SiblingDiv (sibling of header) not found"
            );
            return null;
          }
          console.log("Backup: found level5SiblingDiv");
          const level6Section = level5SiblingDiv.querySelector("section");
          if (!level6Section) {
            console.log("Backup: level6Section not found");
            return null;
          }
          console.log("Backup: found level6Section");

          const level7Div = level6Section.querySelector("div");
          if (!level7Div) {
            console.log("Backup: level7Div not found");
            return null;
          }
          console.log("Backup: found level7Div");

          const firstLevel8Div = level7Div.querySelector("div");
          if (!firstLevel8Div) {
            console.log("Backup: firstLevel8Div not found");
            return null;
          }
          console.log("Backup: found firstLevel8Div");

          const sibLevel8Div = firstLevel8Div.nextElementSibling;
          if (!sibLevel8Div) {
            console.log("Backup: sibLevel8Div not found");
            return null;
          }
          console.log("Backup: found sibLevel8Div");

          // Go down into Level 9 div inside sibLevel8Div
          const level9Div = sibLevel8Div.querySelector("div");
          if (!level9Div) {
            console.log("Backup: level9Div not found");
            return null;
          }
          console.log("Backup: found level9Div");

          // PART 1: Contact Name
          const level10Div = level9Div.querySelector("div");
          if (!level10Div) {
            console.log("Backup: level10Div (name part) not found");
            return null;
          }
          console.log("Backup: found level10Div (name part)");

          const level11Div = level10Div.querySelector("div");
          if (!level11Div) {
            console.log("Backup: level11Div (name part) not found");
            return null;
          }
          console.log("Backup: found level11Div (name part)");

          const level12Span = level11Div.querySelector("span");
          const contactName = level12Span ? level12Span.textContent.trim() : "";
          console.log("Backup: extracted contactName:", contactName);

          // PART 2: Contact Number
          // sibling of level9Div
          const sibLevel9Div = level9Div.nextElementSibling;
          if (!sibLevel9Div) {
            console.log("Backup: sibLevel9Div (number part) not found");
          }
          console.log("Backup: found sibLevel9Div (number part)");

          const level10SpanForNumber = sibLevel9Div.querySelector("span");
          if (!level10SpanForNumber) {
            console.log("Backup: level10SpanForNumber not found");
            return null;
          }
          console.log("Backup: found level10SpanForNumber");

          const level11DivForNumber = level10SpanForNumber.querySelector("div");
          console.log(
            "Backup: extracted contactNumber:",
            level11DivForNumber.textContent.trim()
          );

          return {
            name: contactName,
            number: level11DivForNumber.textContent.trim(),
          };
        } catch {
          return null;
        }
      };

      const businnesAccountCase = () => {
        try {
          const mainDiv = document.getElementById("main");
          if (!mainDiv) {
            console.log("Business Account Case: #main not found");
            return null;
          }
          const outerLayer = mainDiv.parentElement;
          if (!outerLayer) {
            console.log("Businness: outerLayer (parent of #main) not found");
            return null;
          }
          console.log("Businness: found outerLayer");

          // Go to sibling div of outerLayer
          const siblingOfOuterLayer = outerLayer.nextElementSibling;
          if (!siblingOfOuterLayer) {
            console.log("Businness: siblingOfOuterLayer not found");
            return null;
          }
          console.log("Businness: found siblingOfOuterLayer");
          // Drill down inside siblingOfOuterLayer
          const level1Span = siblingOfOuterLayer.querySelector("span");
          if (!level1Span) {
            console.log("Businness: level1Span not found");
            return null;
          }
          console.log("Businness: found level1Span");
          const level2Div = level1Span.querySelector("div");
          if (!level2Div) {
            console.log("Businness: level2Div not found");
            return null;
          }
          console.log("Businness: found level2Div");

          const level3Span = level2Div.querySelector("span");
          if (!level3Span) {
            console.log("Businness: level3Span not found");
            return null;
          }
          console.log("Businness: found level3Span");

          const level4Div = level3Span.querySelector("div");
          if (!level4Div) {
            console.log("Businness: level4Div not found");
            return null;
          }
          console.log("Businness: found level4Div");

          const level5Header = level4Div.querySelector("header");
          if (!level5Header) {
            console.log("Businness: level5Header not found");
            return null;
          }
          console.log("Businness: found level5Header");

          // Get sibling div of level5Header (not inside it)
          const level5SiblingDiv = level5Header.nextElementSibling;
          if (!level5SiblingDiv) {
            console.log(
              "Businness: level5SiblingDiv (sibling of header) not found"
            );
            return null;
          }
          console.log("Businness: found level5SiblingDiv");
          const level6Section = level5SiblingDiv.querySelector("section");
          if (!level6Section) {
            console.log("Businness: level6Section not found");
            return null;
          }
          console.log("Businness: found level6Section");
          const level7Div = level6Section.querySelector("div");

          const firstLevel7Div = level6Section.querySelector("div");
          if (!firstLevel7Div) {
            console.log("Businness: firstLevel8Div not found");
            return null;
          }
          console.log("Businness: found firstLevel8Div");
          const secondLevel7Div = firstLevel7Div.nextElementSibling;
          if (!secondLevel7Div) {
            console.log("Businness: secondLevel8Div not found");
            return null;
          }
          console.log("Businness: found secondLevel8Div");
          const thirdLevel7Div = secondLevel7Div.nextElementSibling;
          if (!thirdLevel7Div) {
            console.log("Businness: thirdLevel8Div not found");
            return null;
          }
          console.log("BUSINEES: found thirdLevel8Div");
          const fourthLevel7Div = thirdLevel7Div.nextElementSibling;
          if (!fourthLevel7Div) {
            console.log("Businness: fourthLevel8Div not found");
            return null;
          }
          console.log("BUSINNES: found fourthLevel8Div");
          const fifthLevel7Div = fourthLevel7Div.nextElementSibling;
          if (!fifthLevel7Div) {
            console.log("Businness: fifthLevel8Div not found");
            return null;
          }
          console.log("Businness: found fifthLevel8Div");
          //make till eleventhlevel8div sibling
          const sixthLevel7Div = fifthLevel7Div.nextElementSibling;
          if (!sixthLevel7Div) {
            console.log("Businness: sixthLevel8Div not found");
            return null;
          }
          console.log("Businness: found sixthLevel8Div");
          const seventhLevel7Div = sixthLevel7Div.nextElementSibling;
          if (!seventhLevel7Div) {
            console.log("Businness: seventhLevel8Div not found");
            return null;
          }
          console.log("Businness: found seventhLevel8Div");
          const eighthLevel7Div = seventhLevel7Div.nextElementSibling;
          if (!eighthLevel7Div) {
            console.log("Businness: eighthLevel8Div not found");
            return null;
          }
          console.log("Businness: found eighthLevel8Div");
          const ninthLevel7Div = eighthLevel7Div.nextElementSibling;
          if (!ninthLevel7Div) {
            console.log("Businness: ninthLevel8Div not found");
            return null;
          }
          console.log("Businness: found ninthLevel8Div");
          const tenthLevel7Div = ninthLevel7Div.nextElementSibling;
          if (!tenthLevel7Div) {
            console.log("Businness: tenthLevel8Div not found");
            return null;
          }
          console.log("Businness: found tenthLevel8Div");
          const eleventhLevel7Div = tenthLevel7Div.nextElementSibling;
          if (!eleventhLevel7Div) {
            console.log("Businness: eleventhLevel8Div not found");
            return null;
          }
          console.log("Businness: FINISHED BIG LEVELS");
          const firstLevel8Div = eleventhLevel7Div.querySelector("div");
          if (!firstLevel8Div) {
            console.log("Businness: Level9Div not found");
            return null;
          }
          console.log("Businness: found Level9Div");
          const secondlevel8Div = firstLevel8Div.nextElementSibling;
          if (!secondlevel8Div) {
            console.log("Businness: secondlevel9Div not found");
            return null;
          }
          console.log("Businness: found secondlevel9Div");
          const thirdLevel8Div = secondlevel8Div.nextElementSibling;
          if (!thirdLevel8Div) {
            console.log("Businness: thirdLevel9Div not found");
            return null;
          }
          console.log("Businness: found thirdLevel9Div");

          const level9Div = thirdLevel8Div.querySelector("div");
          if (!level9Div) {
            console.log("Businness: level10Div not found");
            return null;
          }
          console.log("Businness: found level10Div");
          const level10Div = level9Div.querySelector("div");
          if (!level10Div) {
            console.log("Businness: level11Div not found");
            return null;
          }
          console.log("Businness: found level11Div");
          const level11Span = level10Div.querySelector("span");
          if (!level11Span) {
            console.log("Businness: level12Span not found");
            return null;
          }
          const level12Span = level11Span.querySelector("span");
          if (!level12Span) {
            console.log("Businness: level13span not found");
            return null;
          }
          console.log("Businness: found level12Span");

          return level12Span.textContent.trim();
        } catch (error) {
          console.log("Business Account Case Error:", error);
          return null;
        }
      };

      let primary = extractPrimaryPhone();
      if (primary) primary = primary.replace(/\s/g, "");

      if (primary && isValidPhone(primary)) {
        chrome.runtime.sendMessage({ payload: primary });
      } else {
        const backup = extractBackupNameAndNumber();
        if (!backup) {
          alert("Please Try Opening Conatact Info");
        }

        if (backup && (backup.name || backup.number)) {
          const combined = `${backup.name} ${backup.number}`.trim();
          chrome.runtime.sendMessage({ payload: combined });
        } else {
          if (primary) {
            const businnesAccount = businnesAccountCase();
            if (businnesAccount) {
              const combined = `${primary} ${businnesAccount}`.trim();
              chrome.runtime.sendMessage({ payload: combined });
            }
          } else {
            alert(
              "Please Try Opening Conatact Info, If this issue persist, please report it on the extension's GitHub page."
            );
          }
        }
      }
    },
  });
});

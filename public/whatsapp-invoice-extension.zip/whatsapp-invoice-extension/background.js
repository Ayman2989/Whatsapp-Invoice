chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received:", message);
  if (message.payload) {
    const payload = encodeURIComponent(message.payload.trim());
    chrome.tabs.create({
      url: `https://whatsapp-invoice.vercel.app/invoices/create-invoice?payload=${payload}`,
    });
  }
});
